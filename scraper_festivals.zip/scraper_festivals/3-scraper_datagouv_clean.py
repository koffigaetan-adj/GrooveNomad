import requests
import pandas as pd
from datetime import datetime
import random
import os
from dateutil import parser
from dateutil.relativedelta import relativedelta

# 📡 API data.gouv.fr
BASE_URL = "https://www.data.gouv.fr/api/1/datasets/"
DATASET_ID = "liste-des-festivals-en-france"

# Récupération des métadonnées
resp = requests.get(BASE_URL + DATASET_ID)
data = resp.json()

# Recherche du lien CSV
csv_url = None
for res in data.get("resources", []):
    if "csv" in res["format"].lower() and "festivals" in res["title"].lower():
        csv_url = res["url"]
        break

if not csv_url:
    print("[❌] Aucune ressource CSV trouvée.")
    exit()

# Lecture du CSV
df = pd.read_csv(csv_url, delimiter=";", encoding="utf-8")
print("[ℹ️] Colonnes détectées :", df.columns.tolist())

# Renommage propre (sans date_debut/date_fin car elles n'existent pas)
df = df.rename(columns={
    "\ufeffNom du festival": "Festival Name",
    "Commune principale de déroulement": "City",
    "Région principale de déroulement": "Region",
    "Discipline dominante": "Genre",
    "Site internet du festival": "Website"
})

def random_start_date():
    month = random.choice([8, 9, 10, 11, 12])
    day = random.randint(1, 25)
    return datetime(2025, month, day).strftime("%Y-%m-%d")

df["Start Date"] = df.apply(lambda _: random_start_date(), axis=1)


# Vérification
if "City" not in df.columns or "Region" not in df.columns:
    print("[❌] Colonnes 'City' ou 'Region' manquantes.")
    exit()

# Fonction pour recalculer une date future
def generate_future_date(base_date_str):
    try:
        base_date = parser.parse(str(base_date_str), dayfirst=True)
        now = datetime.now()
        if base_date < now:
            # Décale dans le futur proche ou en 2025
            choice = random.choice(["+1m", "+2m", "oct2025", "dec2025"])
            if choice == "+1m":
                base_date = now + relativedelta(months=1)
            elif choice == "+2m":
                base_date = now + relativedelta(months=2)
            elif choice == "oct2025":
                base_date = datetime(2025, 10, random.randint(5, 20))
            elif choice == "dec2025":
                base_date = datetime(2025, 12, random.randint(1, 15))
        return base_date.strftime("%Y-%m-%d")
    except:
        return (datetime.now() + relativedelta(months=1)).strftime("%Y-%m-%d")

# Champs générés
df["Country"] = "France"
df["Venue"] = df["City"].fillna("Unknown") + " - " + df["Region"].fillna("Unknown")


# Nouvelle fonction qui génère une vraie plage de dates
def generate_date_range(base_date_str):
    try:
        base_date = parser.parse(str(base_date_str), dayfirst=True)
    except:
        base_date = datetime.now()

    now = datetime.now()
    if base_date < now:
        # Redéfinir une date future
        base_date = now + relativedelta(months=random.choice([1, 2, 3]))
    # Ajouter une durée entre 1 et 4 jours
    end_date = base_date + relativedelta(days=random.randint(1, 4))

    return f"{base_date.strftime('%Y-%m-%d')} - {end_date.strftime('%Y-%m-%d')}"

# Application de la nouvelle fonction
df["Dates"] = df["Start Date"].apply(generate_date_range)


# Champs enrichis dynamiquement
df["Capacity"] = df.apply(lambda x: random.randint(2000, 50000), axis=1)
df["Ticket Price (EUR)"] = df.apply(lambda x: round(random.uniform(40, 200), 2), axis=1)
df["Currency"] = "EUR"
df["Ticket Type"] = df.apply(lambda x: random.choice(["Standard", "VIP", "Backstage", "Premium Access"]), axis=1)
df["Accommodation Options"] = df.apply(lambda x: random.choice(["Hotels Nearby", "Camping", "Eco-Lodges", "Airbnb", "Youth Hostel"]), axis=1)
df["Nearest Airport"] = df.apply(lambda x: random.choice(["International Airport", "Regional Airport", "City Airport"]), axis=1)
df["Atmosphere"] = df.apply(lambda x: random.choice(["Chill & Boho", "Rave & Dance", "Underground", "Family Friendly", "Local & Cultural"]), axis=1)
df["Notes"] = df.apply(lambda x: random.choice(["Imported from data.gouv.fr", "Public cultural program", "Recommended by GrooveNomad"]), axis=1)
df["Price Tier 1"] = df["Ticket Price (EUR)"].apply(lambda x: round(x * 0.8, 2))
df["Price Tier 2"] = df["Ticket Price (EUR)"]
df["Price Tier 3"] = df["Ticket Price (EUR)"].apply(lambda x: round(x * 1.2, 2))

# Ordre final
columns_final = [
    "Festival Name", "Dates", "Genre", "City", "Country", "Venue", "Capacity",
    "Website", "Ticket Price (EUR)", "Accommodation Options", "Nearest Airport",
    "Atmosphere", "Notes", "Ticket Type", "Currency",
    "Price Tier 1", "Price Tier 2", "Price Tier 3"
]
df_final = df[columns_final].copy()

# Nettoyage
df_final.dropna(subset=["Festival Name"], inplace=True)
df_final.drop_duplicates(subset=["Festival Name", "Dates", "City", "Country"], inplace=True)
df_final.reset_index(drop=True, inplace=True)

# Création du dossier ./scraper_festivals/csv/
output_dir = os.path.join(os.path.dirname(__file__), "csv")
os.makedirs(output_dir, exist_ok=True)

# Export CSV
output_path = os.path.join(output_dir, "festivals_datagouv_cleaned.csv")
df_final.to_csv(output_path, index=False)

print(f" {len(df_final)} festivals exportés dans {output_path}")
