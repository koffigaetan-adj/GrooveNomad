import pandas as pd
import os

#  Étape 1 : chemin du fichier téléchargé manuellement
CSV_LIMEWIRE = "festivals_limewire.csv"

#  Dossier de sortie
OUTPUT_DIR = "csv"
os.makedirs(OUTPUT_DIR, exist_ok=True)

#  Fichier de sortie avec chemin complet
CSV_OUTPUT = os.path.join(OUTPUT_DIR, "festivals_cleaned_limewire.csv")

#  Colonnes attendues dans la base
EXPECTED_COLUMNS = [
    "Festival Name", "Dates", "Genre", "City", "Country", "Venue", "Capacity",
    "Website", "Ticket Price (EUR)", "Accommodation Options", "Nearest Airport",
    "Atmosphere", "Notes", "Ticket Type", "Currency",
    "Price Tier 1", "Price Tier 2", "Price Tier 3"
]

def load_and_clean_csv(filepath):
    df = pd.read_csv(filepath)

    #  Nettoyage des colonnes
    df.columns = [col.strip() for col in df.columns]
    df = df.applymap(lambda x: str(x).strip() if isinstance(x, str) else x)

    #  Vérification des colonnes
    for col in EXPECTED_COLUMNS:
        if col not in df.columns:
            df[col] = ""

    #  Réorganisation selon l'ordre attendu
    df = df[EXPECTED_COLUMNS]

    print(f" {len(df)} festivals chargés et nettoyés.")
    return df

if __name__ == "__main__":
    df_clean = load_and_clean_csv(CSV_LIMEWIRE)
    df_clean.to_csv(CSV_OUTPUT, index=False)
    print(f" Export effectué vers {CSV_OUTPUT}")
