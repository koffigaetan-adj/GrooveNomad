import pandas as pd
import streamlit as st
import plotly.express as px

# Chargement des données
df = pd.read_csv("scraper_festivals/csv/festivals_merged_cleaned.csv", parse_dates=["Dates"])

df['Dates'] = pd.to_datetime(df['Dates'], errors='coerce', utc=True)
df['Year'] = df['Dates'].dt.year
df['Month'] = df['Dates'].dt.month_name()


st.title(" GrooveNomad – Festival Insights Dashboard")

# Filtrage interactif
country = st.sidebar.multiselect(" Filtrer par pays", df["Country"].unique(), default=df["Country"].unique())
genre = st.sidebar.multiselect(" Filtrer par genre musical", df["Genre"].unique(), default=df["Genre"].unique())

filtered_df = df[df["Country"].isin(country) & df["Genre"].isin(genre)]

# 1. Festivals par pays
st.subheader(" Nombre de festivals par pays")
st.plotly_chart(px.bar(filtered_df.groupby("Country").size().reset_index(name="Count"),
                       x="Country", y="Count"))

# 2. Prix moyen par genre
st.subheader(" Prix moyen par genre musical")
st.plotly_chart(px.bar(filtered_df.groupby("Genre")["Ticket Price (EUR)"].mean().reset_index(),
                       x="Genre", y="Ticket Price (EUR)"))

# 3. Capacité par ambiance
st.subheader(" Capacité moyenne par ambiance")
st.plotly_chart(px.bar(filtered_df.groupby("Atmosphere")["Capacity"].mean().reset_index().sort_values("Capacity", ascending=False),
                       x="Atmosphere", y="Capacity"))

# 4. Festivals par mois
st.subheader(" Répartition mensuelle")
st.plotly_chart(px.histogram(filtered_df, x="Month"))

# 5. Répartition des tickets
st.subheader(" Types de tickets proposés")
st.plotly_chart(px.pie(filtered_df, names="Ticket Type"))

# 6. Prix max par festival
st.subheader(" Prix max (Tier 3) par festival")
st.plotly_chart(px.scatter(filtered_df, x="Festival Name", y="Price Tier 3", color="Country"))
