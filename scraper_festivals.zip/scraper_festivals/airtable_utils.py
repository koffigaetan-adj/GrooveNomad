from pyairtable import Table
import json

with open("config.json") as f:
    config = json.load(f)

table = Table(config["airtable_api_key"], config["base_id"], config["table_name"])

def send_to_airtable(festivals):
    for f in festivals:
        table.create(f)
