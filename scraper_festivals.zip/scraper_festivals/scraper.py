import requests
import pandas as pd

#  URL API Explore V2 (base OpenDataSoft compatible)
BASE_URL = "https://www.data.gouv.fr/api/1/datasets/"

#  Dataset ID de la ressource "festivals"
DATASET_ID = "liste-des-festivals-en-france"

# Appel de l’API pour récupérer les métadonnées du dataset
resp = requests.get(BASE_URL + DATASET_ID)
data = resp.json()

# Recherche de la ressource contenant le CSV
for res in data.get("resources", []):
    if "csv" in res["format"].lower() and "festivals" in res["title"].lower():
        csv_url = res["url"]
        break

# Téléchargement et lecture
df = pd.read_csv(csv_url, delimiter=";", encoding="utf-8")

# Nettoyage + renommage
df = df.rename(columns={
    "nom": "Festival Name",
    "discipline_dominante": "Genre",
    "commune_principale": "City",
    "region": "Region",
    "code_postal": "Postal Code",
    "date_debut": "Start Date",
    "date_fin": "End Date",
    "site_web": "Website"
})
df["Country"] = "France"
df["Source"] = "data.gouv.fr"

# Export
df.to_csv("festivals_datagouv_api.csv", index=False)
print(" Export API V2 réussi vers festivals_datagouv_api.csv")
