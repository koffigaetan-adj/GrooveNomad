import requests
import pandas as pd

API_KEY = "lIVwkXVFID6l1Nka2G6bRinTAhguBTOK"
URL = "https://app.ticketmaster.com/discovery/v2/events.json"

params = {
    "classificationName": "music",
    "keyword": "festival",
    "size": 200,
    "apikey": API_KEY
}

print(" Connexion à l'API Ticketmaster...")
response = requests.get(URL, params=params)

if response.status_code != 200:
    print(f" Erreur API : {response.status_code} - {response.text}")
    exit()

data = response.json()

events = data.get("_embedded", {}).get("events", [])

festivals = []

for event in events:
    name = event.get("name", "")
    url = event.get("url", "")
    date = event.get("dates", {}).get("start", {}).get("localDate", "")
    venue = event.get("_embedded", {}).get("venues", [{}])[0].get("name", "")
    city = event.get("_embedded", {}).get("venues", [{}])[0].get("city", {}).get("name", "")
    country = event.get("_embedded", {}).get("venues", [{}])[0].get("country", {}).get("name", "")
    genre = event.get("classifications", [{}])[0].get("genre", {}).get("name", "")
    price_ranges = event.get("priceRanges", [])

    price_min = price_max = currency = ""
    if price_ranges:
        price_min = price_ranges[0].get("min", "")
        price_max = price_ranges[0].get("max", "")
        currency = price_ranges[0].get("currency", "")

    festivals.append({
        "Festival Name": name,
        "Date": date,
        "City": city,
        "Country": country,
        "Venue": venue,
        "Genre": genre,
        "Min Price": price_min,
        "Max Price": price_max,
        "Currency": currency,
        "Website": url,
        "Source": "Ticketmaster"
    })

df = pd.DataFrame(festivals)
df.to_csv("festivals_ticketmaster.csv", index=False)
print(f" {len(df)} festivals exportés dans festivals_ticketmaster.csv")
