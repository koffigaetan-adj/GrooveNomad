import os
import requests
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.getenv("AIRTABLE_API_KEY")
BASE_ID = os.getenv("AIRTABLE_BASE_ID")
TABLE_NAME = os.getenv("AIRTABLE_TABLE_NAME")

AIRTABLE_URL = f"https://api.airtable.com/v0/{BASE_ID}/{TABLE_NAME}"

headers = {
    "Authorization": f"Bearer {API_KEY}",
    "Content-Type": "application/json"
}

sample_record = {
    "records": [
        {
            "fields": {
                "Name": "Festival Test 2025",
                "Notes": " Festival inséré avec succès depuis Python !"
            }
        }
    ]
}

print(" Envoi vers Airtable...")
response = requests.post(AIRTABLE_URL, headers=headers, json=sample_record)

if response.status_code == 200:
    print(" Festival inséré avec succès !")
    print(response.json())
else:
    print(f" Échec : {response.status_code}")
    print(response.text)
