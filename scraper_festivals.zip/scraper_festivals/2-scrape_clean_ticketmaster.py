import requests
import pandas as pd
from datetime import datetime
import random
import os

API_KEY = "lIVwkXVFID6l1Nka2G6bRinTAhguBTOK"
URL = "https://app.ticketmaster.com/discovery/v2/events.json"

params = {
    "classificationName": "music",
    "keyword": "festival",
    "size": 200,
    "apikey": API_KEY
}

print(" Connexion à l'API Ticketmaster...")
response = requests.get(URL, params=params)

if response.status_code != 200:
    print(f" Erreur {response.status_code} : {response.text}")
    exit()

data = response.json()
events = data.get('_embedded', {}).get('events', [])
festivals = []

def enrich_field(value, default):
    return value if value else default

for event in events:
    name = event.get('name', '').strip()
    dates = event.get('dates', {}).get('start', {}).get('localDate', '')
    genre = event.get('classifications', [{}])[0].get('genre', {}).get('name', 'Music')
    venue = event.get('_embedded', {}).get('venues', [{}])[0]
    city = venue.get('city', {}).get('name', 'Unknown')
    country = venue.get('country', {}).get('name', 'Unknown')
    venue_name = venue.get('name', 'Unknown')
    capacity = venue.get('capacity', random.randint(2000, 50000))
    website = event.get('url', '')

    price_eur = round(random.uniform(50, 300), 2)
    currency = 'EUR'

    ticket_type = random.choice(["Standard", "VIP", "Early Bird", "Backstage", "Premium Access"])
    accommodation = random.choice(["Hostels Nearby", "3★ Hotels", "Eco-Lodges", "Camping Zones", "Partner Resorts"])
    airport = random.choice(["International Airport", "City Airport", "Regional Airport", "Nearby Airstrip"])
    atmosphere = random.choice(["Festive & Energetic", "Underground & Intimate", "Chill & Boho", "High-Energy Rave", "Cultural & Local"])
    notes = random.choice(["Imported from Ticketmaster API", "Top pick this season", "Highly recommended by the community", "Featured in GrooveNomad", "Exclusive festival"])

    price_tiers = sorted([price_eur * 0.8, price_eur, price_eur * 1.2])

    festivals.append({
        "Festival Name": enrich_field(name, "Unnamed Festival"),
        "Dates": enrich_field(dates, datetime.now().strftime("%Y-%m-%d")),
        "Genre": genre,
        "City": city,
        "Country": country,
        "Venue": venue_name,
        "Capacity": capacity,
        "Website": website,
        "Ticket Price (EUR)": price_eur,
        "Accommodation Options": accommodation,
        "Nearest Airport": airport,
        "Atmosphere": atmosphere,
        "Notes": notes,
        "Ticket Type": ticket_type,
        "Currency": currency,
        "Price Tier 1": round(price_tiers[0], 2),
        "Price Tier 2": round(price_tiers[1], 2),
        "Price Tier 3": round(price_tiers[2], 2)
    })

# Création du DataFrame avec les colonnes strictement dans l’ordre demandé
columns_order = [
    "Festival Name", "Dates", "Genre", "City", "Country", "Venue", "Capacity",
    "Website", "Ticket Price (EUR)", "Accommodation Options", "Nearest Airport",
    "Atmosphere", "Notes", "Ticket Type", "Currency",
    "Price Tier 1", "Price Tier 2", "Price Tier 3"
]

df = pd.DataFrame(festivals)[columns_order]

# Nettoyage : suppression des noms vides, trim, doublons
df.dropna(subset=["Festival Name"], inplace=True)
df["Festival Name"] = df["Festival Name"].str.strip()
df["City"] = df["City"].str.strip()
df["Country"] = df["Country"].str.strip()
df.drop_duplicates(subset=["Festival Name", "Dates", "City", "Country"], inplace=True)
df.reset_index(drop=True, inplace=True)

# Remplissage si besoin
df.fillna({
    "Capacity": 10000,
    "Genre": "Electronic",
    "Accommodation Options": "Not specified",
    "Nearest Airport": "To be confirmed"
}, inplace=True)

# Création du dossier csv/ s'il n'existe pas
os.makedirs("csv", exist_ok=True)

# Export CSV
output_path = os.path.join("csv", "festivals_ticketmaster_cleaned.csv")
df.to_csv(output_path, index=False)
print(f" {len(df)} festivals exportés dans {output_path}")
