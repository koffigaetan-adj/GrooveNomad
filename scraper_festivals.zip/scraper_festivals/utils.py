from unidecode import unidecode

def clean_festival(raw):
    raw["Festival Name"] = raw["Festival Name"].strip().title()
    raw["Country"] = unidecode(raw["Country"].strip())
    return raw

def remove_duplicates(festivals):
    seen = set()
    unique = []
    for fest in festivals:
        key = (fest["Festival Name"], fest["Dates"])
        if key not in seen:
            seen.add(key)
            unique.append(fest)
    return unique
