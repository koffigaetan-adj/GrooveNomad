import pandas as pd
import os

#  Répertoire des CSV à fusionner
csv_dir = os.path.join(os.path.dirname(__file__), "csv")

#  Fichiers sources
csv_files = [
    "festivals_ticketmaster_cleaned.csv",
    "festivals_datagouv_cleaned.csv",
    "festivals_cleaned_limewire.csv"  # tu peux adapter si le nom diffère
]

#  Colonnes standard attendues
columns_expected = [
    "Festival Name", "Dates", "Genre", "City", "Country", "Venue", "Capacity",
    "Website", "Ticket Price (EUR)", "Accommodation Options", "Nearest Airport",
    "Atmosphere", "Notes", "Ticket Type", "Currency",
    "Price Tier 1", "Price Tier 2", "Price Tier 3"
]

all_dfs = []

#  Lecture + validation
for csv_name in csv_files:
    path = os.path.join(csv_dir, csv_name)
    if os.path.exists(path):
        df = pd.read_csv(path)
        # vérifie si toutes les colonnes attendues sont là
        missing = set(columns_expected) - set(df.columns)
        if missing:
            print(f" Colonnes manquantes dans {csv_name} : {missing}")
            continue
        all_dfs.append(df[columns_expected])
        print(f" Chargé : {csv_name}")
    else:
        print(f" Fichier non trouvé : {csv_name}")

#  Fusion
if not all_dfs:
    print(" Aucun fichier valide à fusionner.")
    exit()

merged_df = pd.concat(all_dfs, ignore_index=True)

#  Nettoyage
merged_df.dropna(subset=["Festival Name"], inplace=True)
merged_df.drop_duplicates(subset=["Festival Name", "Dates", "City", "Country"], inplace=True)
merged_df.reset_index(drop=True, inplace=True)

#  Export
output_path = os.path.join(csv_dir, "festivals_merged_cleaned.csv")
merged_df.to_csv(output_path, index=False)

print(f" Fusion terminée : {len(merged_df)} festivals exportés dans {output_path}")
